<div align=center>
	<img src="https://capsule-render.vercel.app/api?type=waving&color=auto&height=200&section=header&text=Marvin%20Github!&fontSize=90" />	
</div>

# [1] Header 

![header](https://capsule-render.vercel.app/api?type=egg&color=auto&height=300&section=header&text=Marvin%20Github!&fontSize=90)

wave (default)
egg
shark
slice
rect
soft
rounded
cylinder
waving
transparent


# 📚 Tech Stack 📚
# ✨ Platforms & Languages ✨

<img src="https://img.shields.io/badge/Python-002323?style=flat&logo=Python&logoColor=red"/>

<img src="https://img.shields.io/badge/C++-004713?style=flat&logo=C&logoColor=yellow"/>

<img src="https://img.shields.io/badge/Python-007396?style=flat&logo=Conda-Forge&logoColor=white"/>


### [2] source code
```python
import os
print('hello')
```

### [3] bullet point
* bullet point
    * abc
        * 123


### [4] link 
[Google](http://usaco.org/)

### [5] image 
![gold](/resource/gold.png)

